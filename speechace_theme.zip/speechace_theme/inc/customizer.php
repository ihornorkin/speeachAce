<?php

function theme_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	$total_pages = get_pages(array('hide_empty' => 0));
	foreach ($total_pages as $total_pages_single) {
		$total_page_choice[$total_pages_single->ID] = $total_pages_single->post_title; 
	}

	/*============HOME PANEL============*/
	$wp_customize->add_panel(
		'home_panel',
		array(
			'title' => __( 'Home Sections' ),
			'priority' => 20
		)
	);

	/*============TOP SECTION============*/
	$wp_customize->add_section(
		'top_section',
		array(
			'title'			=> __( 'Top Section' ),
			'panel'         => 'home_panel'
		)
	);

		$wp_customize->add_setting(
			'top_title',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_title',
			array(
				'settings'		=> 'top_title',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Title' )
			)
		);

		$wp_customize->add_setting(
			'top_subtitle',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_subtitle',
			array(
				'settings'		=> 'top_subtitle',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Subtitle' )
			)
		);

		$wp_customize->add_setting(
				'top_image',
				array(
					'sanitize_callback' => 'esc_url_raw'
				)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
			    $wp_customize,
			    'top_image',
			    array(
			            'section' => 'top_section',
			            'settings' => 'top_image',
			            'description' => __('Top image')
			    )
			)
		);

		$wp_customize->add_setting(
			'top_buttons',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);			

		$wp_customize->add_control(
			new Customize_Heading(
				$wp_customize,
				'top_buttons',
				array(
					'settings'		=> 'top_buttons',
					'section'		=> 'top_section',
					'label'			=> __( 'Buttons ' )
				)
			)
		);

		$wp_customize->add_setting(
			'top_btn1',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_btn1',
			array(
				'settings'		=> 'top_btn1',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Button 1 Text' )
			)
		);

		$wp_customize->add_setting(
			'top_btn1_url',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_btn1_url',
			array(
				'settings'		=> 'top_btn1_url',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Button 1 Link' )
			)
		);				

		$wp_customize->add_setting(
			'top_btn2',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_btn2',
			array(
				'settings'		=> 'top_btn2',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Button 2 Text' )
			)
		);

		$wp_customize->add_setting(
			'top_btn2_url',
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'top_btn2_url',
			array(
				'settings'		=> 'top_btn2_url',
				'section'		=> 'top_section',
				'type'			=> 'text',
				'label'			=> __( 'Button 2 Link' )
			)
		);	
	
	/*============MAIN SECTION PANEL============*/
	/*$wp_customize->add_section(
		'main_section',
		array(
			'title' 			=> __( 'Main Section', 'total' ),
			'panel'				=> 'home_panel'
		)
	);

	for( $i = 1; $i < 5; $i++ ){
		$wp_customize->add_setting(
			'total_featured_header'.$i,
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			new Customize_Heading(
				$wp_customize,
				'total_featured_header'.$i,
				array(
					'settings'		=> 'total_featured_header'.$i,
					'section'		=> 'main_section',
					'label'			=> __( 'Section ', 'total' ).$i
				)
			)
		);

        $wp_customize->add_setting(
            'main_page_title'.$i,
            array(
                'sanitize_callback' => 'sanitize_text'
            )
        );

        $wp_customize->add_control(
            'main_page_title'.$i,
            array(
                'settings'		=> 'main_page_title'.$i,
                'section'		=> 'main_section',
                'type'			=> 'text',
                'label'			=> __( 'Title', 'total' )
            )
        );

		$wp_customize->add_setting(
			'total_featured_page'.$i,
			array(
				'sanitize_callback' => 'absint'
			)
		);

		$wp_customize->add_control(
			'total_featured_page'.$i,
			array(
				'settings'		=> 'total_featured_page'.$i,
				'section'		=> 'main_section',
				'type'			=> 'dropdown-pages',
				'label'			=> __( 'Page link', 'total' )
			)
		);

		$wp_customize->add_setting(
			'section_desc'.$i,
			array(
				'sanitize_callback' => 'sanitize_text'
			)
		);

		$wp_customize->add_control(
			'section_desc'.$i,
			array(
				'settings'		=> 'section_desc'.$i,
				'section'		=> 'main_section',
				'type'			=> 'textarea',
				'label'			=> __( 'Description', 'total' )
			)
		);

		$wp_customize->add_setting(
			'main_img'.$i,
			array(
				'sanitize_callback' => 'esc_url_raw',
				'default'			=> get_template_directory_uri().'/img/wearemcw1.jpg'
			)
		);

		$wp_customize->add_control(
		    new WP_Customize_Image_Control(
		        $wp_customize,
		        'main_img'.$i,
		        array(
		            'label' => __( 'Upload Image', 'total' ),
		            'section' => 'main_section',
		            'settings' => 'main_img'.$i,
		            'description' => __('Recommended Image Size: 1440X650px', 'total')
		        )
		    )
		);
	}
	*/
	/*============ FOOTER COPYRIGHT ============*/
	/*$wp_customize->add_section(
		'footer_section',
		array(
			'title'			=> __( 'Footer', 'total' ),
			'panel'         => 'home_panel'
		)
	);

	$wp_customize->add_setting(
		'footer_copyright',
		array(
			'sanitize_callback' => 'sanitize_text'
		)
	);

	$wp_customize->add_control(
		'footer_copyright',
		array(
			'settings'		=> 'footer_copyright',
			'section'		=> 'footer_section',
			'type'			=> 'textarea',
			'label'			=> __( 'Copyright text', 'total' )
		)
	);

	$wp_customize->add_setting(
		'insta_link',
		array(
			'sanitize_callback' => 'sanitize_text'
		)
	);

	$wp_customize->add_control(
		'insta_link',
		array(
			'settings'		=> 'insta_link',
			'section'		=> 'footer_section',
			'type'			=> 'text',
			'label'			=> __( 'Instagram link', 'total' )
		)
	);

	$wp_customize->add_setting(
		'tw_link',
		array(
			'sanitize_callback' => 'sanitize_text'
		)
	);

	$wp_customize->add_control(
		'tw_link',
		array(
			'settings'		=> 'tw_link',
			'section'		=> 'footer_section',
			'type'			=> 'text',
			'label'			=> __( 'Twitter link', 'total' )
		)
	);

	$wp_customize->add_setting(
		'youtube_link',
		array(
			'sanitize_callback' => 'sanitize_text'
		)
	);

	$wp_customize->add_control(
		'youtube_link',
		array(
			'settings'		=> 'youtube_link',
			'section'		=> 'footer_section',
			'type'			=> 'text',
			'label'			=> __( 'Youtube link', 'total' )
		)
	);
	*/
}
add_action( 'customize_register', 'theme_customize_register' );

function customizer_script() {
	wp_enqueue_script( 'total-customizer-script', get_template_directory_uri() .'/inc/js/customizer-scripts.js', array("jquery"),'', true  );
}
add_action( 'customize_controls_enqueue_scripts', 'customizer_script' );

if( class_exists( 'WP_Customize_Control' ) ):	

class Total_Dropdown_Chooser extends WP_Customize_Control{
	public $type = 'dropdown_chooser';

	public function render_content(){
		if ( empty( $this->choices ) )
                return;
		?>
            <label>
                <span class="customize-control-title">
                	<?php echo esc_html( $this->label ); ?>
                </span>

                <?php if($this->description){ ?>
	            <span class="description customize-control-description">
	            	<?php echo wp_kses_post($this->description); ?>
	            </span>
	            <?php } ?>

                <select class="hs-chosen-select" <?php $this->link(); ?>>
                    <?php
                    foreach ( $this->choices as $value => $label )
                        echo '<option value="' . esc_attr( $value ) . '"' . selected( $this->value(), $value, false ) . '>' . esc_html( $label ) . '</option>';
                    ?>
                </select>
            </label>
		<?php
	}
}

class Customize_Heading extends WP_Customize_Control {
	public $type = 'heading';

    public function render_content() {
    	if ( !empty( $this->label ) ) : ?>
            <h3 style="background: white;padding: 0.5rem;border: 1px solid #19b5e4;color: #075082;"><?php echo esc_html( $this->label ); ?></h3>
        <?php endif;

        if($this->description){ ?>
			<span class="description customize-control-description">
			<?php echo wp_kses_post($this->description); ?>
			</span>
		<?php }
    }
}

class Total_Info_Text extends WP_Customize_Control{

    public function render_content(){
    ?>
	    <span class="customize-control-title">
			<?php echo esc_html( $this->label ); ?>
		</span>

		<?php if($this->description){ ?>
			<span class="description customize-control-description">
			<?php echo wp_kses_post($this->description); ?>
			</span>
		<?php }
    }

}

endif;


//SANITIZATION FUNCTIONS
function sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}

function total_sanitize_checkbox( $input ) {
    if ( $input == 1 ) {
        return 1;
    } else {
        return '';
    }
}

function total_sanitize_integer( $input ) {
    if( is_numeric( $input ) ) {
        return intval( $input );
    }
}

function total_sanitize_choices( $input, $setting ) {
    global $wp_customize;
 
    $control = $wp_customize->get_control( $setting->id );
 
    if ( array_key_exists( $input, $control->choices ) ) {
        return $input;
    } else {
        return $setting->default;
    }
}

function total_sanitize_choices_array( $input, $setting ) {
    global $wp_customize;
 	
 	if(!empty($input)){
    	$input = array_map('absint', $input);
    }

    return $input;
} 