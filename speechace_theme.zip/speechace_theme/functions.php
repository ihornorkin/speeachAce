<?php

add_theme_support( 'custom-logo' );

add_filter('widget_text', 'do_shortcode');

function register_my_menu() {
  register_nav_menus(
  	array(
  	  'header-r-menu' => __( 'Header Right Menu' ),
  	  'header-l-menu' => __( 'Header Left Menu' )
  	)
  );	
}
add_action( 'init', 'register_my_menu' );


function enqueue_styles() {
    wp_register_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.css');
    wp_enqueue_style( 'bootstrap' );
    wp_register_style( 'bootstrap-theme', get_template_directory_uri() . '/css/bootstrap-theme.css');
    wp_enqueue_style( 'bootstrap-theme' );
    wp_register_style( 'app.min', get_template_directory_uri() . '/css/app.min.css');
    wp_enqueue_style( 'app.min' );
  	wp_register_style( 'fonts.raleway', 'https://fonts.googleapis.com/css?family=Raleway:400,500,600,800');
  	wp_enqueue_style( 'fonts.raleway' );

}
add_action('wp_enqueue_scripts', 'enqueue_styles');

function enqueue_scripts () {
	wp_register_script( 'jquery.min', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js' );
    wp_enqueue_script( 'jquery.min' );
    wp_register_script('app.min.js', get_stylesheet_directory_uri() . '/js/app.min.js');
    wp_enqueue_script( 'app.min.js' );
    wp_register_script( 'retina.min.js', get_template_directory_uri() . '/js/retina.js' );
    wp_enqueue_script( 'retina.min.js' );
    wp_register_script( 'bootstrap.min', get_template_directory_uri() . '/js/bootstrap.min.js' );
    wp_enqueue_script( 'bootstrap.min' );
}
add_action('wp_enqueue_scripts', 'enqueue_scripts');

require get_template_directory() . '/inc/customizer.php';

add_theme_support('post-thumbnails');

/*remove_filter('the_content', 'wpautop');*/

add_action( 'init', 'my_add_excerpts_to_pages' );
function my_add_excerpts_to_pages() {
    add_post_type_support( 'page', 'excerpt' );
}

?>