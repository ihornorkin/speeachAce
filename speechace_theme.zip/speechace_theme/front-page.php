<?php get_header(); ?>
            <!-- Map image-->
        <div class="intro-section__img-map">
        <?php $top_image = get_theme_mod('top_image'); ?>
          <img src="<?php echo esc_url($top_image)?>" data-rjs="3" class="img-responsive center-block" />
        </div>
        <!-- Description-->
        <div class="intro-section__description text-center">
        <?php $top_title = get_theme_mod('top_title'); ?>
          <h1><?php echo esc_html($top_title); ?></h1>
        <?php $top_subtitle = get_theme_mod('top_subtitle'); ?>
          <h2><?php echo esc_html($top_subtitle); ?></h2>
        </div>
        <!--Buttons group-->
        <div class="intro-section__buttons text-center clearfix">
          <div class="col-md-6">
          <?php $top_btn1 = get_theme_mod('top_btn1'); ?>
          <?php $top_btn1_url = get_theme_mod('top_btn1_url'); ?>
            <a href="<?php echo esc_html($top_btn1_url); ?>" class="btn sa-btn pull-right"><?php echo esc_html($top_btn1); ?></a>
          </div>
          <div class="col-md-6">
          <?php $top_btn2 = get_theme_mod('top_btn2'); ?>
          <?php $top_btn2_url = get_theme_mod('top_btn2_url'); ?>
            <a href="<?php echo esc_html($top_btn2_url); ?>" class="btn sa-btn pull-left"><?php echo esc_html($top_btn2); ?></a>
          </div>
        </div>
      </div>
    </div>
    <div class="what-we-do">
      <div class="container">
        <div class="what-we-do__top-description text-center">
          <div class="section-heading">
            <h2>What We Do</h2>
            <div class="section-heading__duplicate">
              <span class="section-heading__heading">What We Do</span>
            </div>
          </div>
          <h3>Speech Recognition Software For Pronunciation Improvement</h3>
        </div>
        <div class="what-we-do__image">
          <img src="<?php echo get_template_directory_uri(); ?>/images/graphic-what-we-do.png" data-rjs="3" class="img-responsive" />
        </div>
        <div class="col-md-8 col-md-push-2">
          <div class="what-we-do__bottom-description text-center">
            <p>We develop speech recognition software that assists language learners in improving their pronunciation and lowering
              their accent. Our system is different from other speech recognition technologies because of our ability to recognize
              individual syllables and phonemes in any audio sample. We are then able to pinpoint the exact syllables and phonemes
              that a user is speaking incorrectly.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="section-api">
      <div class="container">
        <div class="section-api__top-description text-center">
          <div class="section-heading">
            <h2>SpeechAce API</h2>
            <div class="section-heading__duplicate">
              <span class="section-heading__heading">SpeechAce API</span>
            </div>
          </div>
          <h3>Web based API for evaluating any audio sample.</h3>
        </div>
        <div class="col-md-10 col-md-push-1">
          <div class="api-steps">
            <div class="api-steps__item">
              <img src="<?php echo get_template_directory_uri(); ?>/images/item-1.png" data-rjs="3" class="img-responsive" />
            </div>
            <div class="api-steps__item">
              <img src="<?php echo get_template_directory_uri(); ?>/images/item-2.png" data-rjs="3" class="img-responsive" />
            </div>
            <div class="api-steps__item">
              <img src="<?php echo get_template_directory_uri(); ?>/images/item-3.png" data-rjs="3" class="img-responsive" />
            </div>
            <div class="api-steps__item">
              <img src="<?php echo get_template_directory_uri(); ?>/images/item-4.png" data-rjs="3" class="img-responsive" />
            </div>
            <div class="api-steps__item">
              <img src="<?php echo get_template_directory_uri(); ?>/images/item-5.png" data-rjs="3" class="img-responsive" />
            </div>
          </div>
        </div>
        <div class="col-md-8 col-md-push-2">
          <div class="section-api__bottom-description text-center">
            <p>As of now we only share our API with a limited set of partners. If you are interested in using our API then please
              send us a request using the form in the Contact section below and we will get back to you within 24 hours.</p>
          </div>
        </div>
      </div>
    </div>
    <div class="management-system">
      <div class="container">
        <div class="management-system__top-description">
          <div class="section-heading">
            <h2>Learning Management System</h2>
            <div class="section-heading__duplicate">
              <span class="section-heading__heading">Learning Management System</span>
            </div>
          </div>
          <h3 class="text-center">Create online pronunciation practice content based on our speech recognition technology.</h3>
        </div>
        <div class="management-system__logos"></div>
        <div class="management-system__main">
          <div class="col-md-6">
            <img src="" />
          </div>
          <div class="col-md-6"></div>
        </div>
        <div class="management-system__btn-group">
          <div class="col-md-6">
            <button class="btn sa-btn pull-right">Other LMS Options</button>
          </div>
          <div class="col-md-6">
            <button class="btn sa-btn pull-left">Free Moodle Trial</button>
          </div>
        </div>
      </div>
    </div>
    <div class="trusted">
      <div class="container">
        <div class="trusted__top-description text-center">
          <div class="section-heading">
            <h2>Trusted and used by</h2>
            <div class="section-heading__duplicate">
              <span class="section-heading__heading">Trusted and used by</span>
            </div>
          </div>
        </div>
        <div class="col-md-10 col-md-push-1">
          <div class="trusted__cards">
            <div class="trusted-card">
              <div class="trusted-card__wrapper">
                <img src="<?php echo get_template_directory_uri(); ?>/images/city-university-logo.png" data-rjs="3" />
              </div>
            </div>
            <div class="trusted-card">
              <div class="trusted-card__wrapper">
                <img src="<?php echo get_template_directory_uri(); ?>/images/uni-orientale-logo.png" data-rjs="3" />
              </div>
            </div>
            <div class="trusted-card">
              <div class="trusted-card__wrapper">
                <img src="<?php echo get_template_directory_uri(); ?>/images/hero-logo.png" data-rjs="3" />
              </div>
            </div>
          </div>
          <div class="trusted__quotes">
            <div class="col-md-6">
              <div class="quote-card">
                <div class="quote-card__wrapper">
                  <blockquote>“The greatest proportion of students listed SpeechAce as their favorite part, based on their appreciation of the
                    native speaker model and accompanying phonetic transcription.”</blockquote>
                  <span class="quote-card__name">J. Aiello, Instructor at University of Naples</span>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="quote-card">
                <div class="quote-card__wrapper">
                  <blockquote>“The greatest proportion of students listed SpeechAce as their favorite part, based on their appreciation of the
                    native speaker model and accompanying phonetic transcription.”</blockquote>
                  <span class="quote-card__name">J. Aiello, Instructor at University of Naples</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="our-team">
      <div class="our-team__img-map">
        <img src="<?php echo get_template_directory_uri(); ?>/images/world-map-2.png" />
      </div>
      <div class="container">
        <div class="our-team__top-description text-center">
          <div class="section-heading section-heading--white">
            <h2>Our Team</h2>
            <div class="section-heading__duplicate">
              <span class="section-heading__heading">Our Team</span>
            </div>
          </div>
          <h3>Improving pronunciation one syllable at a time.</h3>
        </div>
        <div class="our-team__team-gallery">
          <div class="row">
            <div class="team-gallery">
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-1.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">John Doe</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-2.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-3.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-4.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-5.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-6.jpg" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-7-placeholder-1.png" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
              <div class="team-gallery__item">
                <div class="team-gallery__wrapper">
                  <img src="<?php echo get_template_directory_uri(); ?>/images/item-8-placeholder-2.png" />
                  <div class="team-gallery__person-info">
                    <div class="team-gallery__name">Name</div>
                    <div class="team-gallery__position">Position</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-10 col-md-push-1">
          <div class="our-team__bottom-description text-center">
            <p>We are a team of experienced software developers, linguists and business development personnel. We are passionate about
              learning languages and every team member speaks at least two languages. SpeechAce was founded because some of our
              team members wanted to develop a tool that they could use to reduce their native accent while speaking English.</p>
            <p>We understand the pain of not being able to speak a language fluently and therefore work hard every day to develop
              best in class products for our customers.</p>
          </div>
        </div>
        <div class="our-team__contact-btn text-center">
          <button class="btn sa-btn">Contact Us</button>
        </div>
      </div>
    </div>
  </body>

</html>
